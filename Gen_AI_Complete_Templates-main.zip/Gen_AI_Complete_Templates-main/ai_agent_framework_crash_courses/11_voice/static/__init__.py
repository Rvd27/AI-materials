# Static voice agent example
